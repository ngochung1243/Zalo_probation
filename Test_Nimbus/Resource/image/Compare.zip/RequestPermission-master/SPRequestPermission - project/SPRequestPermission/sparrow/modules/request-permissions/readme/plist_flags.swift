//NSCameraUsageDescription

//NSBluetoothPeripheralUsageDescription

//NSCalendarsUsageDescription

//NSContactsUsageDescription

//NSHealthShareUsageDescription

//NSHealthUpdateUsageDescription

//NSHomeKitUsageDescription

//NSLocationAlwaysUsageDescription

//NSLocationUsageDescription

//NSLocationWhenInUseUsageDescription

//NSAppleMusicUsageDescription

//NSMicrophoneUsageDescription

//NSMotionUsageDescription

//kTCCServiceMediaLibrary

//NSPhotoLibraryUsageDescription

//NSRemindersUsageDescription

//NSSiriUsageDescription

//NSSpeechRecognitionUsageDescription

//NSVideoSubscriberAccountUsageDescription

//Background Mode
    //key: NSLocationAlwaysUsageDescription
    //value: location
